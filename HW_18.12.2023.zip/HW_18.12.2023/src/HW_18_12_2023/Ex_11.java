package HW_18_12_2023;

public class Ex_11 {
    public static void main (String[] args){


    }
}
